import xianyu
#from utils import color_format_logging


def main(*_):
    print("xianyu...")
    #color_format_logging.main()
    #ai_api_ephone.main()


if __name__ == "__main__":
    main()